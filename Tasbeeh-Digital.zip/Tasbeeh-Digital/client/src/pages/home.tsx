import TasbihCounter from "@/components/TasbihCounter";
import generatedBg from "@assets/generated_images/dark_teal_and_gold_islamic_geometric_pattern_background.png";

export default function Home() {
  return (
    <div className="relative min-h-screen w-full overflow-hidden flex flex-col items-center justify-center p-4">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 z-0 bg-cover bg-center bg-no-repeat opacity-40 mix-blend-overlay"
        style={{ backgroundImage: `url(${generatedBg})` }}
      />
      <div className="absolute inset-0 z-0 bg-gradient-to-b from-background via-background/95 to-background" />

      {/* Content */}
      <div className="relative z-10 w-full max-w-md flex flex-col items-center">
        <header className="mb-12 text-center">
          <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-accent via-white to-accent drop-shadow-sm mb-2 font-sans">
            المسبحة الإلكترونية
          </h1>
          <p className="text-muted-foreground text-sm font-light tracking-wide opacity-80">
            اذكر الله يذكرك
          </p>
        </header>

        <main className="w-full">
          <TasbihCounter />
        </main>

        <footer className="mt-16 text-center">
          <p className="text-xs text-white/20 font-light">
            تصميم مخصص للذكر والتسبيح
          </p>
        </footer>
      </div>
    </div>
  );
}
