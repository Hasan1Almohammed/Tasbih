import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { RotateCcw, Settings, Volume2, VolumeX, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";

interface TasbihCounterProps {
  initialGoal?: number;
}

export default function TasbihCounter({ initialGoal = 33 }: TasbihCounterProps) {
  const [count, setCount] = useState(0);
  const [goal, setGoal] = useState(initialGoal);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [cycle, setCycle] = useState(0);

  // Progress calculation
  const progress = goal === Infinity ? 0 : (count / goal) * 100;
  
  const handleIncrement = () => {
    // Haptic feedback pattern (simulated visual shake in UI if needed, or browser vibration API)
    if (navigator.vibrate && soundEnabled) {
      navigator.vibrate(10);
    }

    if (goal !== Infinity && count >= goal) {
      // Goal reached
      setCount(1);
      setCycle(c => c + 1);
      if (navigator.vibrate && soundEnabled) {
        navigator.vibrate([50, 50, 50]);
      }
    } else {
      setCount(c => c + 1);
    }
  };

  const handleReset = () => {
    setCount(0);
    setCycle(0);
    if (navigator.vibrate && soundEnabled) {
      navigator.vibrate(20);
    }
  };

  const toggleSettings = () => setShowSettings(!showSettings);

  return (
    <div className="relative flex flex-col items-center justify-center w-full max-w-md mx-auto">
      {/* Main Counter Circle */}
      <div className="relative mb-12 group">
        {/* Glow Effects */}
        <div className="absolute inset-0 rounded-full bg-primary/20 blur-3xl scale-110 animate-pulse" />
        
        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={handleIncrement}
          className="relative z-10 flex items-center justify-center w-72 h-72 rounded-full glass-panel emerald-glow border-4 border-primary/30 group-hover:border-primary/50 transition-colors duration-500"
          data-testid="button-increment"
        >
          {/* Progress Ring SVG */}
          <svg className="absolute inset-0 w-full h-full -rotate-90 pointer-events-none" viewBox="0 0 100 100">
            <circle
              cx="50"
              cy="50"
              r="46"
              fill="none"
              stroke="hsl(var(--secondary))"
              strokeWidth="4"
              className="opacity-50"
            />
            {goal !== Infinity && (
              <motion.circle
                cx="50"
                cy="50"
                r="46"
                fill="none"
                stroke="hsl(var(--primary))"
                strokeWidth="4"
                strokeLinecap="round"
                initial={{ pathLength: 0 }}
                animate={{ pathLength: count / goal }}
                transition={{ duration: 0.2, ease: "easeOut" }}
              />
            )}
          </svg>

          <div className="flex flex-col items-center z-20 pointer-events-none select-none">
            <motion.span 
              key={count}
              initial={{ y: 10, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              className="text-7xl font-bold text-white tabular-nums tracking-tight drop-shadow-lg"
            >
              {count}
            </motion.span>
            <span className="text-accent text-sm mt-2 font-medium tracking-widest uppercase opacity-80">
              {goal === Infinity ? "مفتوح" : `الهدف: ${goal}`}
            </span>
            {cycle > 0 && (
              <span className="text-muted-foreground text-xs mt-1">
                الدورة: {cycle}
              </span>
            )}
          </div>
        </motion.button>
      </div>

      {/* Controls */}
      <div className="flex items-center gap-6 z-10">
        <Button
          variant="outline"
          size="icon"
          onClick={handleReset}
          className="w-12 h-12 rounded-full border-white/10 bg-black/20 text-white hover:bg-white/10 hover:text-accent transition-colors"
          data-testid="button-reset"
        >
          <RotateCcw className="w-5 h-5" />
        </Button>

        <Button
          variant="outline"
          size="icon"
          onClick={toggleSettings}
          className={cn(
            "w-14 h-14 rounded-full border-accent/30 bg-accent/10 text-accent hover:bg-accent/20 hover:text-accent-foreground transition-all duration-300 gold-glow",
            showSettings && "bg-accent text-accent-foreground"
          )}
          data-testid="button-settings"
        >
          <Settings className="w-6 h-6 animate-spin-slow" />
        </Button>

        <Button
          variant="outline"
          size="icon"
          onClick={() => setSoundEnabled(!soundEnabled)}
          className="w-12 h-12 rounded-full border-white/10 bg-black/20 text-white hover:bg-white/10 hover:text-accent transition-colors"
          data-testid="button-sound"
        >
          {soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
        </Button>
      </div>

      {/* Settings Panel */}
      <AnimatePresence>
        {showSettings && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="absolute bottom-24 w-full max-w-xs glass-panel p-4 rounded-2xl z-20"
          >
            <h3 className="text-white font-bold mb-4 text-center">إعدادات الهدف</h3>
            <div className="grid grid-cols-3 gap-2">
              {[33, 99, Infinity].map((g) => (
                <button
                  key={g}
                  onClick={() => {
                    setGoal(g);
                    setCount(0);
                    setCycle(0);
                    setShowSettings(false);
                  }}
                  className={cn(
                    "py-2 rounded-lg text-sm font-medium transition-all",
                    goal === g 
                      ? "bg-primary text-white shadow-lg" 
                      : "bg-white/5 text-muted-foreground hover:bg-white/10 hover:text-white"
                  )}
                >
                  {g === Infinity ? "∞" : g}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
